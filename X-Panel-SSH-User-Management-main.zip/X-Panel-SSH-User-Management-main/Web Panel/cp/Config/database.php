<?php
$port = "22";
$username = "adminuser";
$password = "adminpass";
$dbname = "XPanel";
$lang = "fa-ir";

define("DB_TYPE", "mysql");
define("DB_HOST", "localhost");
define("DB_NAME", $dbname);
define("DB_USER", $username);
define("DB_PASS", $password);
define("PORT", $port);
define("LANG", $lang);
date_default_timezone_set("Asia/Tehran");
